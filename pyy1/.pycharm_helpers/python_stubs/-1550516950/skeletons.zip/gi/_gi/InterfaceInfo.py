# encoding: utf-8
# module gi._gi
# from /usr/lib/python3/dist-packages/gi/_gi.cpython-35m-x86_64-linux-gnu.so
# by generator 1.145
# no doc

# imports
import _gobject as _gobject # <module '_gobject'>
import _glib as _glib # <module '_glib'>
import gi as __gi
import gobject as __gobject


class InterfaceInfo(__gi.RegisteredTypeInfo):
    # no doc
    def find_method(self, *args, **kwargs): # real signature unknown
        pass

    def find_signal(self, *args, **kwargs): # real signature unknown
        pass

    def find_vfunc(self, *args, **kwargs): # real signature unknown
        pass

    def get_constants(self, *args, **kwargs): # real signature unknown
        pass

    def get_iface_struct(self, *args, **kwargs): # real signature unknown
        pass

    def get_methods(self, *args, **kwargs): # real signature unknown
        pass

    def get_prerequisites(self, *args, **kwargs): # real signature unknown
        pass

    def get_properties(self, *args, **kwargs): # real signature unknown
        pass

    def get_signals(self, *args, **kwargs): # real signature unknown
        pass

    def get_vfuncs(self, *args, **kwargs): # real signature unknown
        pass

    def __init__(self, *args, **kwargs): # real signature unknown
        pass


